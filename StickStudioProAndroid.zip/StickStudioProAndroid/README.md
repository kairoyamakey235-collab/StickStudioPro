# Stick Studio Pro Android wrapper

This Android Studio project wraps the supplied Stick Studio Pro editor in an Android WebView and registers the app as a handler for shared/opened files. It accepts Android `ACTION_VIEW` and `ACTION_SEND` intents and passes the selected file's name and UTF-8 text into the editor's `window.importExternalFile()` importer.

## Build an APK
1. Install Android Studio (recent stable version) and Android SDK Platform 35.
2. Open this `StickStudioProAndroid` folder in Android Studio.
3. Let Gradle sync and install any requested SDK/build components.
4. Choose **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
5. Android Studio creates the APK under `app/build/outputs/apk/debug/`.
6. Install that APK on the Android device.

## Open a Stick Nodes file
After installing the APK, download a supported figure file, open it from Downloads or a file manager, and select **Stick Studio Pro** from Android's app chooser. Android may show **Just once** or **Always**. If Android does not show the app for a particular file, use Share > Stick Studio Pro or the app's Import button.

## Compatibility note
Android file handlers are registered broadly for content/file URIs because Stick Nodes extensions do not have consistent MIME types across download providers. The editor importer supports readable XML/JSON-based files; proprietary packed/encrypted `.nodemc` variants may still require a format-specific decoder. This project has not been compiled or tested on a physical Android device in this environment.
